/* @ds-bundle: {"format":3,"namespace":"DesignSystem_9fe380","components":[],"sourceHashes":{},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.DesignSystem_9fe380 = window.DesignSystem_9fe380 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

})();
