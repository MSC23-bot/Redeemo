# Redeemo Admin Panel — working notes

## Standing instruction: always report where to find changes
After completing ANY task, end the reply with a short "Where to find it" note that tells the user exactly how to navigate to what changed:
- The sidebar group and nav item to click (e.g. "Content and Taxonomy → Legal / T&C / FAQ").
- Any role gate — which role must be active in the top-bar avatar switcher to see it (e.g. "set role to Super Admin or Content").
- The specific tab, dialog, or button within the screen, and how to trigger it.
Keep it concrete and step-by-step so the user can find it without hunting.

## Screen → nav location reference (shellScreen id → where it lives)
- contractchannels → Content and Taxonomy → "Legal / T&C / FAQ" (gated: Super Admin, Content)
- taxonomy → Content and Taxonomy → Taxonomy Management
- leads → Relationships → Leads and Onboarding
- tasks → Relationships → Tasks and Follow-ups
- members → Members → Members and Subscriptions
- comms → (Communications nav item)
- reviewsmod → Trust and Safety → Reviews Moderation
- suggtags → Trust and Safety → Suggested-tag Moderation
- fraud → Trust and Safety → Fraud and Reversals
- cases → Support and Cases → Case Queue
- dsar → Support and Cases → DSAR / Data Requests (gated: Super Admin, Support)

## Role switching
Top-bar avatar cycles roles in order: OPERATIONS → SUPER_ADMIN → SALES → FINANCE → SUPPORT → CONTENT. Live role does not persist across a fresh file open (resets to Operations).
